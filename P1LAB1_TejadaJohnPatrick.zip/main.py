first_name = input("")
welcome_message = f"Hello {first_name} and welcome to CS Online!"
print(welcome_message)
''' Type your code here. '''